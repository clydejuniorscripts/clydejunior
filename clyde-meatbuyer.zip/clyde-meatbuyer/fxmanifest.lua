fx_version 'cerulean'
game 'gta5'

author 'clydejunior'
description 'Zombie Meat Buyer'
version '1.0.0'

shared_script 'config.lua'

server_script 'server.lua'

client_script 'client.lua'

files {
    'locales/en.lua'
}

lua54 'yes'
