# Simple script to sell items illegal or not (whatever) nothing to fancy

# Dependencies

- qbcore
- qb-target
- ox_lib https://github.com/overextended/ox_lib/releases/tag/v2.19.1
