
fx_version 'cerulean'

author 'KevinGirardx'

game 'gta5'

client_scripts {
	'client/*.lua',
}

server_scripts {
	'server/*.lua',
}

shared_scripts {
	'@ox_lib/init.lua',
	'config.lua',
}

lua54 'yes'
