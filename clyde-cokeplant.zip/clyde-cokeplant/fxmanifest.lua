-- fxmanifest.lua
fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'QBCore Coca Plant Drug System'
version '1.0.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

lua54 'yes'
