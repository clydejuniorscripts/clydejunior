fx_version 'cerulean'
game 'gta5'

description 'Clyde Wholesale Shop'

client_scripts {
    'config.lua',
    'client.lua'
}

server_scripts {
    'config.lua',
    'server.lua'
}

dependencies {
    'qb-core',
    'qb-target',
    'qb-menu',
    'qb-inventory'
}
