
fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'QBCore Mining Job'
version '1.0.0'

shared_scripts {
    'config.lua' -- Load config globally
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}
