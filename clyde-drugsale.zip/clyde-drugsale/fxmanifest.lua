
fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'QBCore Drug Dealing Script with NPC Movement Fix'
version '1.2.2'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

shared_script 'config.lua'
