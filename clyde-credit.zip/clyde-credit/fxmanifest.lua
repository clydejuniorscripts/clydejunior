-- fxmanifest.lua

fx_version 'cerulean'
game 'gta5'

author 'Your Name'
description 'Credit Score System'
version '1.0.0'

server_script 'server.lua'
client_script 'client.lua'
shared_script 'config.lua'
