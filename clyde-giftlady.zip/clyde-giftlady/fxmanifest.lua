fx_version 'cerulean'
game 'gta5'

author 'clydejunior'
version '1.2.0'

client_script {
    'client.lua'
}

server_script {
	'server.lua'
}

shared_script 'config.lua'
